package com.karachristos.vending.vendingmachine.utils;

import com.karachristos.vending.vendingmachine.entities.Position;

import java.util.ArrayList;

public class PositionUtil {

    ArrayList<Position> positions ;
    private int rows;
    private int columns;

    public PositionUtil(ArrayList<Position> positions, int rows, int columns) {
        this.positions = positions;
        this.rows = rows;
        this.columns = columns;
    }

    public ArrayList<Position> potions_final(){
        return null; //TODO("GIVE THE POSITIONS NAMES !!!!!!!!!")
    }

}
