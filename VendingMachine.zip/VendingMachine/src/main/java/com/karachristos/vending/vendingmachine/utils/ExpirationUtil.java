package com.karachristos.vending.vendingmachine.utils;

public class ExpirationUtil {
}