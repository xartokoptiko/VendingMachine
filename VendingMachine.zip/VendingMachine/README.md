# VendingMachine Simulator

## Description

Vending machine simulator is a semister java exercise for students to test their abilities. This particular exercise belongs to the students : 

- Lampros Karachristos (Λαμπρος Καραχρηστος)
- George Kousanas      (Γεωργιος Κουσανας)

## Instructions

The program will first start on the "VendingMachine Master" window where the user gets to initialize the machine based on he's/her's preferences ! In order for this to work the user needs to follow these instruction or the simulator wont continew to the initialization :

1. The "Rows of shelf" and "Shelves" and the dimensions to be greater than 0
2. The "Rows of shelf" and "Shelves" to be less than 10
3. The "Number od products" "Experation date" "Product" "Cost" not empty
4. The "experation date" to be a valid date !  